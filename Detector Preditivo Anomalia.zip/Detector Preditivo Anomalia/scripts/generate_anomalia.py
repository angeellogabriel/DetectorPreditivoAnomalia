import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import os

# Garante que a pasta 'data' exista
os.makedirs('data', exist_ok=True)

# Parâmetros
total_minutos = 1440  # 1 dia de dados com amostragem de 1 min
porcentagem_anomalias = 0.05  # 5% de anomalias

# Gerar timestamps
inicio = datetime(2024, 1, 1, 0, 0, 0)
timestamps = [inicio + timedelta(minutes=i) for i in range(total_minutos)]

# Gerar sinais normais
temperatura = np.random.normal(loc=72, scale=0.5, size=total_minutos)
vibracao = np.random.normal(loc=0.03, scale=0.005, size=total_minutos)

# Inserir anomalias
n_anomalias = int(total_minutos * porcentagem_anomalias)
indices_anomalias = np.random.choice(total_minutos, n_anomalias, replace=False)

temperatura[indices_anomalias] += np.random.uniform(10, 25, size=n_anomalias)  # até 100°C
vibracao[indices_anomalias] += np.random.uniform(0.2, 0.5, size=n_anomalias)

# Montar DataFrame
df = pd.DataFrame({
    'timestamp': timestamps,
    'temperatura': np.round(temperatura, 2),
    'vibracao': np.round(vibracao, 3)
})

# Salvar CSV
df.to_csv('data/sensor_data.csv', index=False)

# Plot opcional
plt.figure(figsize=(10, 4))
plt.plot(df['timestamp'], df['temperatura'], label='Temperatura')
plt.plot(df['timestamp'], df['vibracao'] * 1000, label='Vibração (x1000)', alpha=0.7)
plt.title("Dados simulados de sensores com anomalias")
plt.xlabel("Tempo")
plt.ylabel("Valor")
plt.legend()
plt.tight_layout()
plt.show()
