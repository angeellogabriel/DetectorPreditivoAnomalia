import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras import regularizers

# 1. Carregar os dados
df = pd.read_csv("data/sensor_data.csv", parse_dates=["timestamp"])
df_features = df[["temperatura", "vibracao"]]

# 2. Treinar apenas com dados normais (sem picos)
df_train = df_features[(df_features["temperatura"] < 75) & (df_features["vibracao"] < 0.05)]

# 3. Normalizar os dados
scaler = MinMaxScaler()
X_train = scaler.fit_transform(df_train)
X_full = scaler.transform(df_features)

# 4. Criar o Autoencoder
input_dim = X_train.shape[1]
input_layer = Input(shape=(input_dim,))
encoded = Dense(4, activation="relu", activity_regularizer=regularizers.l1(1e-5))(input_layer)
decoded = Dense(input_dim, activation="sigmoid")(encoded)
autoencoder = Model(inputs=input_layer, outputs=decoded)
from tensorflow.keras.losses import MeanSquaredError
autoencoder.compile(optimizer='adam', loss=MeanSquaredError())


# 5. Treinar o modelo
history = autoencoder.fit(X_train, X_train,
                          epochs=50,
                          batch_size=32,
                          shuffle=True,
                          validation_split=0.1,
                          verbose=1)

# 6. Calcular erro de reconstrução em todos os dados
X_pred = autoencoder.predict(X_full)
mse = np.mean(np.square(X_full - X_pred), axis=1)

# 7. Definir limiar de anomalia
limiar = np.percentile(mse, 95)

# 8. Marcar anomalias
df["mse"] = mse
df["anomaly"] = df["mse"] > limiar

# 9. Plot
plt.figure(figsize=(12, 4))
plt.plot(df["timestamp"], df["mse"], label="Erro de Reconstrução")
plt.axhline(y=limiar, color='r', linestyle='--', label="Limiar")
plt.title("Erro de Reconstrução e Limiar de Detecção")
plt.xlabel("Tempo")
plt.ylabel("MSE")
plt.legend()
plt.tight_layout()
plt.show()

# 10. Salvar o modelo e scaler
autoencoder.save("models/autoencoder_sensor.h5")
import joblib
joblib.dump(scaler, "models/scaler.pkl")
