import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import load_model
import joblib
from sklearn.metrics import confusion_matrix

# 1. Carregar modelo e scaler
autoencoder = load_model("models/autoencoder_sensor.h5", compile=False)

scaler = joblib.load("models/scaler.pkl")

# 2. Carregar novos dados
df = pd.read_csv("data/sensor_data.csv", parse_dates=["timestamp"])
df_features = df[["temperatura", "vibracao"]]
X_scaled = scaler.transform(df_features)

# 3. Predição com o Autoencoder
X_pred = autoencoder.predict(X_scaled)
mse = np.mean(np.square(X_scaled - X_pred), axis=1)

# 4. Calcular limiar novamente (ou fixe um valor se preferir)
limiar = np.percentile(mse, 95)

# 5. Detectar anomalias
df["mse"] = mse
df["anomaly"] = mse > limiar

# 6. Plot com destaque visual
plt.figure(figsize=(12, 4))
plt.plot(df["timestamp"], df["temperatura"], label="Temperatura")
plt.scatter(df[df["anomaly"]]["timestamp"], df[df["anomaly"]]["temperatura"], color='red', label="Anomalias", s=20)
plt.title("Detecção de Anomalias na Temperatura")
plt.xlabel("Tempo")
plt.ylabel("Temperatura (°C)")
plt.legend()
plt.tight_layout()
plt.show()

# 7. Salvar o resultado
df.to_csv("data/sensor_data_anotado.csv", index=False)
print("✅ Resultado salvo em: data/sensor_data_anotado.csv")
