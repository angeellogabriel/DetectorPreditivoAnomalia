import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import pandas as pd
import plotly.graph_objs as go

# 1. Carrega o dataset anotado
df = pd.read_csv("C:\\Users\\angel\\OneDrive\\Área de Trabalho\\Projetos\\Detector Preditivo Anomalia\\data\\sensor_data_anotado.csv", parse_dates=["timestamp"])


# 2. Inicializa o app Dash
app = dash.Dash(__name__)
app.title = "Dashboard de Manutenção Preditiva"

# 3. Layout
app.layout = html.Div([
    html.H2("🔧 Monitoramento de Sensores - Manutenção Preditiva", style={'textAlign': 'center'}),

    html.Div([
        html.Div([
            html.H4("📈 Temperatura com Anomalias"),
            dcc.Graph(id='grafico-temperatura'),
        ], className='six columns'),

        html.Div([
            html.H4("📊 Contador de Anomalias"),
            html.Div(id='contador-anomalias', style={'fontSize': '32px', 'color': 'red', 'textAlign': 'center'})
        ], className='six columns'),
    ], className='row'),

    html.Div([
        html.H4("🧪 Vibração"),
        dcc.Graph(id='grafico-vibracao')
    ])
])

# 4. Callback que atualiza os gráficos e contador
@app.callback(
    [Output('grafico-temperatura', 'figure'),
     Output('grafico-vibracao', 'figure'),
     Output('contador-anomalias', 'children')],
    Input('grafico-temperatura', 'id')  # dummy trigger só para rodar ao carregar
)
def atualizar_dashboard(_):
    # Temperatura
    fig_temp = go.Figure()
    fig_temp.add_trace(go.Scatter(x=df["timestamp"], y=df["temperatura"],
                                  mode='lines', name='Temperatura'))
    fig_temp.add_trace(go.Scatter(x=df[df["anomaly"]]["timestamp"],
                                  y=df[df["anomaly"]]["temperatura"],
                                  mode='markers', name='Anomalias',
                                  marker=dict(color='red', size=6)))
    fig_temp.update_layout(title="Temperatura com Anomalias", xaxis_title="Tempo", yaxis_title="°C")

    # Vibração
    fig_vib = go.Figure()
    fig_vib.add_trace(go.Scatter(x=df["timestamp"], y=df["vibracao"],
                                 mode='lines', name='Vibração'))
    fig_vib.update_layout(title="Vibração ao longo do tempo", xaxis_title="Tempo", yaxis_title="g")

    # Contador de anomalias
    total_anomalias = df["anomaly"].sum()
    texto = f"⚠️ {total_anomalias} anomalias detectadas"

    return fig_temp, fig_vib, texto

# 5. Executa o servidor
if __name__ == '__main__':
    app.run(debug=True)